/**********************************************************************
 "Copyright 1990-2013 Brian MacWhinney. Use is subject to Gnu Public License
 as stated in the attached "gpl.txt" file."
 */

#define CHAT_MODE 0
#include "cu.h"

#if !defined(UNX)
#define _main temp_main
#define call temp_call
#define getflag temp_getflag
#define init temp_init
#define usage temp_usage
#endif

#define IS_WIN_MODE FALSE
#include "mul.h" 

extern struct tier *defheadtier;
extern char OverWriteFile;
extern char outputOnlyData;
extern char *AddCEXExtension;


void usage() {
	printf("Usage: temp [%s] filename(s)\n", mainflgs());
	mainusage(TRUE);
	cutt_exit(0);
}

void init(char f) {
	if (f) {
		stout = FALSE;
		OverWriteFile = TRUE;
		outputOnlyData = TRUE;
		FilterTier = 0;
		LocalTierSelect = TRUE;
		AddCEXExtension = ".txt";
		if (defheadtier != NULL) {
			if (defheadtier->nexttier != NULL)
				free(defheadtier->nexttier);
			free(defheadtier);
			defheadtier = NULL;
		}
	} else {
	}
}

CLAN_MAIN_RETURN main(int argc, char *argv[]) {
	isWinMode = IS_WIN_MODE;
	chatmode = CHAT_MODE;
	CLAN_PROG_NUM = TEMP;
	OnlydataLimit = 0;
	UttlineEqUtterance = TRUE;
	bmain(argc,argv,NULL);
}
		
void getflag(char *f, char *f1, int *i) {
	f++;
	switch(*f++) {
		default:
			maingetflag(f-2,f1,i);
			break;
	}
}

static void flipLong(unsigned long *num) {
	char *s, t0, t1, t2, t3;
	
	s = (char *)num;
	t0 = s[0];
	t1 = s[1];
	t2 = s[2];
	t3 = s[3];
	s[3] = t0;
	s[2] = t1;
	s[1] = t2;
	s[0] = t3;
}

static void flipShort(unsigned short *num) {
	char *s, t0, t1;
	
	s = (char *)num;
	t0 = s[0];
	t1 = s[1];
	s[1] = t0;
	s[0] = t1;
}

void call() {
	int c, cnt;
	unsigned long *ni;
	unsigned short *ns;
	unsigned char nc;
	char sc[2], si[4];

	if (fpin != NULL && fpin != stdin) {
		fclose(fpin);
		fpin = fopen(oldfname, "rb");
		if (fpin == NULL)
			return;
	}
	cnt = 0;
	while (!feof(fpin)) {
		c = fgetc(fpin);
		templineC[cnt++] = (char)c;
		if (cnt >= UTTLINELEN)
			break;
	}
	for (c=0; c < cnt; c++) {
		sc[0] = templineC[c];
		sc[1] = templineC[c+1];
		ns = (unsigned short *)sc;
		si[0] = templineC[c];
		si[1] = templineC[c+1];
		si[2] = templineC[c+2];
		si[3] = templineC[c+3];
		ni = (unsigned long *)si;
		nc = (unsigned char)templineC[c];
		fprintf(fpout, "char=%d (%x); ", (int)nc, nc);
//		fprintf(fpout, "short=%d; int=%ld; ", *ns, *ni);
		flipShort(ns);
		flipLong(ni);
//		fprintf(fpout, "short=%d; int=%ld", *ns, *ni);
		fprintf(fpout, "\n");
	}
}
