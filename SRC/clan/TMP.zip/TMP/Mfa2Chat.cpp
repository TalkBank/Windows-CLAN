/**********************************************************************
	"Copyright 1990-2022 Brian MacWhinney. Use is subject to Gnu Public License
	as stated in the attached "gpl.txt" file."
*/

#define CHAT_MODE 0

#include "cu.h"
#ifndef UNX
	#include "ced.h"
#endif
/* // NO QT
#ifdef _WIN32
	#include <TextUtils.h>
#endif
*/
#if !defined(UNX)
#define _main mfa2chat_main
#define call mfa2chat_call
#define getflag mfa2chat_getflag
#define init mfa2chat_init
#define usage mfa2chat_usage
#endif

#define IS_WIN_MODE FALSE
#include "mul.h" 

extern struct tier *defheadtier;
extern char OverWriteFile;
extern char cutt_isMultiFound;
extern char fgets_cr_lc;

#define UTF8_code  1
#define UTF16_code 2
#define ANSI_code  0

#define UMAC 1
#define UPC  2

#define TAGSLEN  128

struct SecFileInfo {
	FNType fname[FILENAME_MAX];
	long lineno;
	FILE *fp;
} ;
typedef struct SecFileInfo SECFILE;

struct TiersRec {
    char *sp;
    char *line;
	long beg;
	long end;
	struct TiersRec *sameSP;
	struct TiersRec *nextMfaTier;
} ;
typedef struct TiersRec P2C_TIERS;

struct MfaAtribsRec {
	char tag[TAGSLEN];
	char chatName[TAGSLEN];
	char depOn[TAGSLEN];
	struct MfaAtribsRec *nextTag;
} ;
typedef struct MfaAtribsRec ATTRIBS;

#define P2C_LINESEG struct P2C_LineBulletSegment
struct P2C_LineBulletSegment {
	char *text;
	long beg, end;
	P2C_LINESEG *nextSeg;
} ;

#define P2C_CHATTIERS struct ChatTiers
struct ChatTiers {
	char isWrap;
	char isOverlapOrig;
	long beg, end;
	unsigned short wordCnt;
	char *sp;
	P2C_LINESEG *lineSeg;
	P2C_LINESEG *lastLineSeg;
	P2C_CHATTIERS *depTiers;
	P2C_CHATTIERS *nextTier;
} ;

enum {
	SP_MODE = 1,
	TIER_MODE,
} ;

static char lang[TAGSLEN+1];
static char isMultiBullets;
static char mediaFName[FILENAME_MAX+2];
static P2C_CHATTIERS *RootTiers;
static ATTRIBS *attsRoot;
static unsigned short lEncode;
#ifdef _MAC_CODE
static TextEncodingVariant lVariant;
#endif

void usage() {
	printf("convert and merge Praat TextGrid files to CHAT files\n");
	printf("Usage: mfa2chat [b dF oS %s] filename(s)\n",mainflgs());
	puts("+b:  Specify that multiple bullets per line (default only one bullet per line).");
    puts("+dF: specify attribs/tags dependencies file F.");
	puts("+oS: Specify code page. Please type \"+o?\" for full listing of codes");
	puts("     utf8  - Unicode UTF-8");
	puts("     macl  - Mac Latin (German, Spanish ...)");
	puts("     pcl   - PC  Latin (German, Spanish ...)");
	mainusage(FALSE);
	puts("\nExample: mfa2chat +b -opcl bysoc1ny-06-TEL.TextGrid");
	puts("\tmfa2chat +b -opcl +dpraat_attribs.cut odderny-05-HFU.TextGrid");
	cutt_exit(0);
}

void init(char s) {
	if (s) {
		OverWriteFile = TRUE;
		AddCEXExtension = ".cha";
		stout = FALSE;
		onlydata = 1;
		RootTiers = NULL;
		attsRoot = NULL;
		isMultiBullets = FALSE;
		strcpy(lang, "UNK");
		lEncode = 0;
#ifdef _MAC_CODE
		lVariant = kTextEncodingDefaultVariant;
#endif
		if (defheadtier) {
			if (defheadtier->nexttier != NULL)
				free(defheadtier->nexttier);
			free(defheadtier);
			defheadtier = NULL;
		}
		addword('\0','\0',"+</?>");
		addword('\0','\0',"+</->");
		addword('\0','\0',"+<///>");
		addword('\0','\0',"+<//>");
		addword('\0','\0',"+</>");  // list R6 in mmaininit funtion in cutt.c
		addword('\0','\0',"+xxx");
		addword('\0','\0',"+yyy");
		addword('\0','\0',"+www");
		addword('\0','\0',"+xxx@s*");
		addword('\0','\0',"+yyy@s*");
		addword('\0','\0',"+www@s*");
		addword('\0','\0',"+&*");
		addword('\0','\0',"+-*");
		addword('\0','\0',"+#*");
		addword('\0','\0',"+(*.*)");
		addword('\0','\0',"+0*");
		addword('\0','\0',"+<#>");
	}
}

static ATTRIBS *freeAttribs(ATTRIBS *p) {
	ATTRIBS *t;
	
	while (p != NULL) {
		t = p;
		p = p->nextTag;
		free(t);
	}
	return(NULL);
}

static void freeLineSeg(P2C_LINESEG *p) {
	P2C_LINESEG *t;
	
	while (p != NULL) {
		t = p;
		p = p->nextSeg;
		if (t->text != NULL)
			free(t->text);
		free(t);
	}
}

static P2C_CHATTIERS *freeTiers(P2C_CHATTIERS *p) {
	P2C_CHATTIERS *t;
	
	while (p != NULL) {
		t = p;
		p = p->nextTier;
		if (t->depTiers != NULL)
			freeTiers(t->depTiers);
		if (t->sp != NULL)
			free(t->sp);
		if (t->lineSeg != NULL)
			freeLineSeg(t->lineSeg);
		free(t);
	}
	return(NULL);
}

static void freeMfa2ChatMem(void) {
	attsRoot = freeAttribs(attsRoot);
	RootTiers = freeTiers(RootTiers);
}

static ATTRIBS *add_each_praatTag(ATTRIBS *root, const char *fname, long ln, const char *tag, const char *chatName, const char *depOn) {
	long len;
	ATTRIBS *p, *tp;
	
	if (tag[0] == EOS)
		return(root);
	
	if (root == NULL) {
		if ((p=NEW(ATTRIBS)) == NULL)
			out_of_mem();
		root = p;
	} else {
		for (p=root; p->nextTag != NULL && uS.mStricmp(p->tag, tag); p=p->nextTag) ;
		if (uS.mStricmp(p->tag, tag) == 0)
			return(root);
		
		if ((p->nextTag=NEW(ATTRIBS)) == NULL)
			out_of_mem();
		p = p->nextTag;
	}
	
	p->nextTag = NULL;
	if ((strlen(tag) >= TAGSLEN) || (strlen(depOn) >= TAGSLEN) || (strlen(chatName) >= TAGSLEN)) {
		freeMfa2ChatMem();
		fprintf(stderr,"\n*** File \"%s\"", fname);
		if (ln != 0)
			fprintf(stderr,": line %ld.\n", ln);
		fprintf(stderr, "Tag(s) too long. Longer than %d characters\n", TAGSLEN);
		cutt_exit(0);
	}
	strcpy(p->tag, tag);
	strcpy(p->chatName, chatName);
	if (p->chatName[0] == '@' || p->chatName[0] == '*' || p->chatName[0] == '%') {
		len = strlen(p->chatName) - 1;
		if (p->chatName[len] != ':')
			strcat(p->chatName, ":");
	}
	if (depOn[0] != EOS && chatName[0] != '*') {
		for (tp=root; tp != NULL; tp=tp->nextTag) {
			if (uS.mStricmp(tp->tag, depOn) == 0 || uS.partcmp(tp->chatName, depOn, FALSE, FALSE))
				break;
		}
		if (tp == NULL) {
			freeMfa2ChatMem();
			fprintf(stderr,"\n*** File \"%s\"", fname);
			if (ln != 0)
				fprintf(stderr,": line %ld.\n", ln);
			fprintf(stderr, " ** Can't match praat tag \"%s\" to any speaker declaration in attributes file.\n", depOn);
			cutt_exit(0);
		}
		strcpy(p->depOn, tp->chatName);
	} else
		strcpy(p->depOn, depOn);
	
	return(root);
}

static void rd_MfaAtts_f(const char *fname, char isFatalError) {
	int  cnt;
	const char *tag, *depOn, *chatName;
	char isQF;
	long i, j, ln;
	FNType mFileName[FNSize];
	FILE *fp;
	
	if (*fname == EOS) {
		fprintf(stderr,	"No dep. tags file specified.\n");
		cutt_exit(0);
	}
	if ((fp=OpenGenLib(fname,"r",TRUE,FALSE,mFileName)) == NULL) {
		fprintf(stderr, "\n    Warning: Not using any attribs file: \"%s\", \"%s\"\n\n", fname, mFileName);
		if (isFatalError)
			cutt_exit(0);
		else {
//			fprintf(stderr, "    Please specify attribs file with +d option.\n\n");
			return;
		}
	}
	ln = 0L;
	while (fgets_cr(templineC, 255, fp)) {
		if (uS.isUTF8(templineC) || uS.isInvisibleHeader(templineC))
			continue;
		ln++;
		if (templineC[0] == '#' || templineC[0] == ';')
			continue;
		uS.remblanks(templineC);
		if (templineC[0] == EOS)
			continue;
		i = 0;
		cnt = 0;
		tag = "";
		chatName = "";
		depOn = "";
		while (1) {
			isQF = 0;
			for (; isSpace(templineC[i]); i++) ;
			if (templineC[i] == '"' || templineC[i] == '\'') {
				isQF = templineC[i];
				i++;
			}
			for (j=i; (!isSpace(templineC[j]) || isQF) && templineC[j] != EOS; j++) {
				if (templineC[j] == isQF) {
					isQF = 0;
					strcpy(templineC+j, templineC+j+1);
					j--;
				}
			}
			if (cnt == 0)
				tag = templineC+i;
			else if (cnt == 1)
				chatName = templineC+i;
			else if (cnt == 2)
				depOn = templineC+i;
			if (templineC[j] == EOS)
				break;
			templineC[j] = EOS;
			i = j + 1;
			cnt++;
		}
		if (tag[0] == EOS || chatName[0] == EOS) {
			freeMfa2ChatMem();
			fprintf(stderr,"\n*** File \"%s\": line %ld.\n", fname, ln);
			if (tag[0] == EOS)
				fprintf(stderr, "Missing Praat tag\n");
			else if (chatName[0] == EOS)
				fprintf(stderr, "Missing Chat tier name for \"%s\"\n", tag);
			cutt_exit(0);
		}
		if (depOn[0] == EOS && chatName[0] == '%') {
			freeMfa2ChatMem();
			fprintf(stderr,"\n*** File \"%s\": line %ld.\n", fname, ln);
			fprintf(stderr, "Missing \"Associated with tag\" for \"%s\"\n", tag);
			cutt_exit(0);
		}
		attsRoot = add_each_praatTag(attsRoot, fname, ln, tag, chatName, depOn);
	}
	fclose(fp);
}

CLAN_MAIN_RETURN main(int argc, char *argv[]) {
	isWinMode = IS_WIN_MODE;
	chatmode = CHAT_MODE;
	CLAN_PROG_NUM = MFA2CHAT;
	OnlydataLimit = 0;
	UttlineEqUtterance = FALSE;
	bmain(argc,argv,NULL);
	attsRoot = freeAttribs(attsRoot);
}

static void cleanup_lang(char *lang) {
	while (*lang) {
		if (isSpace(*lang) || *lang < (unCH)' ')
			strcpy(lang, lang+1);
		else
			lang++;
	}
	if (*(lang-1) == ',')
		strcpy(lang-1, lang);
}

void getflag(char *f, char *f1, int *i) {
	f++;
	switch(*f++) {
		case 'b':
			isMultiBullets = TRUE;
			no_arg_option(f);
			break;
		case 'd':
			if (*f) {
				rd_MfaAtts_f(getfarg(f,f1,i), TRUE);
			} else {
				fprintf(stderr,"Missing argument to option: %s\n", f-2);
				cutt_exit(0);
			}
			break;
		case 'l':
			if (*f) {
				strncpy(lang, getfarg(f,f1,i), TAGSLEN);
				lang[TAGSLEN] = EOS;
				cleanup_lang(lang);
			} else {
				fprintf(stderr,"Missing argument to option: %s\n", f-2);
				cutt_exit(0);
			}
			break;
		case 'o':
			lEncode = UTF8;
#ifdef _MAC_CODE
			if (!uS.mStricmp(f, "utf8"))
				lEncode = 0xFFFF;
			else if (!uS.mStricmp(f, "macl"))
				lEncode = kTextEncodingMacRoman;
			else if (!uS.mStricmp(f, "macce"))
				lEncode = kTextEncodingMacCentralEurRoman;
			else if (!uS.mStricmp(f, "pcl"))
				lEncode = kTextEncodingWindowsLatin1;
			else if (!uS.mStricmp(f, "pcce"))
				lEncode = kTextEncodingWindowsLatin2;
			
			else if (!uS.mStricmp(f, "macar"))
				lEncode = kTextEncodingMacArabic;
			else if (!uS.mStricmp(f, "pcar"))
				lEncode = kTextEncodingDOSArabic;
			
			else if (!uS.mStricmp(f, "maccs"))
				lEncode = kTextEncodingMacChineseSimp;
			else if (!uS.mStricmp(f, "macct"))
				lEncode = kTextEncodingMacChineseTrad;
			else if (!uS.mStricmp(f, "pccs"))
				lEncode = kTextEncodingDOSChineseSimplif;
			else if (!uS.mStricmp(f, "pcct"))
				lEncode = kTextEncodingDOSChineseTrad;
			
			else if (!uS.mStricmp(f, "maccr"))
				lEncode = kTextEncodingMacCroatian;
			
			else if (!uS.mStricmp(f, "maccy"))
				lEncode = kTextEncodingMacCyrillic;
			else if (!uS.mStricmp(f, "pccy"))
				lEncode = kTextEncodingWindowsCyrillic;
			
			else if (!uS.mStricmp(f, "machb"))
				lEncode = kTextEncodingMacHebrew;
			else if (!uS.mStricmp(f, "pchb"))
				lEncode = kTextEncodingDOSHebrew;
			
			else if (!uS.mStricmp(f, "macjp"))
				lEncode = kTextEncodingMacJapanese;
			else if (!uS.mStricmp(f, "pcjp"))
				lEncode = kTextEncodingDOSJapanese;
			else if (!uS.mStricmp(f, "macj1"))
				lEncode = kTextEncodingJIS_X0201_76;
			else if (!uS.mStricmp(f, "macj2"))
				lEncode = kTextEncodingJIS_X0208_83;
			else if (!uS.mStricmp(f, "macj3"))
				lEncode = kTextEncodingJIS_X0208_90;
			else if (!uS.mStricmp(f, "macj4"))
				lEncode = kTextEncodingJIS_X0212_90;
			else if (!uS.mStricmp(f, "macj5"))
				lEncode = kTextEncodingJIS_C6226_78;
			else if (!uS.mStricmp(f, "macj6"))
				lEncode = kTextEncodingShiftJIS_X0213_00;
			else if (!uS.mStricmp(f, "macj7"))
				lEncode = kTextEncodingISO_2022_JP;
			else if (!uS.mStricmp(f, "macj8"))
				lEncode = kTextEncodingISO_2022_JP_1;
			else if (!uS.mStricmp(f, "macj9"))
				lEncode = kTextEncodingISO_2022_JP_2;
			else if (!uS.mStricmp(f, "macj10"))
				lEncode = kTextEncodingISO_2022_JP_3;
			else if (!uS.mStricmp(f, "macj11"))
				lEncode = kTextEncodingEUC_JP;
			else if (!uS.mStricmp(f, "macj12"))
				lEncode = kTextEncodingShiftJIS;
			
			else if (!uS.mStricmp(f, "krn"))
				lEncode = kTextEncodingMacKorean;
			else if (!uS.mStricmp(f, "pckr"))
				lEncode = kTextEncodingDOSKorean;
			else if (!uS.mStricmp(f, "pckrj"))
				lEncode = kTextEncodingWindowsKoreanJohab;
			
			else if (!uS.mStricmp(f, "macth"))
				lEncode = kTextEncodingMacThai;
			else if (!uS.mStricmp(f, "pcth"))
				lEncode = kTextEncodingDOSThai;
			
			else if (!uS.mStricmp(f, "pcturk"))
				lEncode = kTextEncodingWindowsLatin5; // kTextEncodingDOSTurkish
			
			else if (!uS.mStricmp(f, "macvt"))
				lEncode = kTextEncodingMacVietnamese;
			else if (!uS.mStricmp(f, "pcvt"))
				lEncode = kTextEncodingWindowsVietnamese;
			else {
				if (*f != '?')
					fprintf(stderr,"Unrecognized font option \"%s\". Please use:\n", f);
				puts("     utf8  - Unicode UTF-8");
				displayOoption();
				cutt_exit(0);
			}
#endif
#ifdef _WIN32 
			if (!uS.mStricmp(f, "utf8"))
				lEncode = 0xFFFF;
			else if (!uS.mStricmp(f, "pcl"))
				lEncode = 1252;
			else if (!uS.mStricmp(f, "pcce"))
				lEncode = 1250;
			
			else if (!uS.mStricmp(f, "pcar"))
				lEncode = 1256;
			
			else if (!uS.mStricmp(f, "pccs"))
				lEncode = 936;
			else if (!uS.mStricmp(f, "pcct"))
				lEncode = 950;
			
			else if (!uS.mStricmp(f, "pccy"))
				lEncode = 1251;
			
			else if (!uS.mStricmp(f, "pchb"))
				lEncode = 1255;
			
			else if (!uS.mStricmp(f, "pcjp"))
				lEncode = 932;
			
			else if (!uS.mStricmp(f, "krn"))
				lEncode = 949;
			else if (!uS.mStricmp(f, "pckr"))
				lEncode = 949;
			else if (!uS.mStricmp(f, "pckrj"))
				lEncode = 1361;
			
			else if (!uS.mStricmp(f, "pcth"))
				lEncode = 874;
			
			else if (!uS.mStricmp(f, "pcturk"))
				lEncode = 1254; // 857
			
			else if (!uS.mStricmp(f, "pcvt"))
				lEncode = 1258;
			else {
				if (*f != '?')
					fprintf(stderr,"Unrecognized font option \"%s\". Please use:\n", f);
				puts("     utf8  - Unicode UTF-8");
				displayOoption();
				cutt_exit(0);
			}
#endif
			break;
		default:
			maingetflag(f-2,f1,i);
			break;
	}
}

static void Mfa_addLineSeg(P2C_CHATTIERS *nt, long beg, long end, const char *line, char isAddBullet) {
	P2C_LINESEG *seg;

	if (nt->lineSeg == NULL) {
		if ((nt->lineSeg=NEW(P2C_LINESEG)) == NULL)
			out_of_mem();
		seg = nt->lineSeg;
		nt->lastLineSeg = seg;
	} else {
//		for (seg=nt->lineSeg; seg->nextSeg != NULL; seg=seg->nextSeg) ;
		seg = nt->lastLineSeg;
		if ((seg->nextSeg=NEW(P2C_LINESEG)) == NULL)
			out_of_mem();
		seg = seg->nextSeg;
		nt->lastLineSeg = seg;
	}
	seg->nextSeg = NULL;
	seg->beg = beg;
	seg->end = end;

	if (isAddBullet && (beg != 0L || end != 0L))
		sprintf(templineC3, " %c%ld_%ld%c", HIDEN_C, beg, end, HIDEN_C);
	else
		templineC3[0] = EOS;

	seg->text = (char *)malloc(strlen(line)+strlen(templineC3)+1);
	if (seg->text == NULL)
		out_of_mem();
	strcpy(seg->text, line);
	if (templineC3[0] != EOS)
		strcat(seg->text, templineC3);
}

static void Mfa_fillNT(P2C_CHATTIERS *nt, long beg, long end, const char *sp, const char *line, char isAddBullet) {
	nt->depTiers = NULL;
	nt->isWrap = TRUE;
	nt->sp = (char *)malloc(strlen(sp)+1);
	if (nt->sp == NULL) out_of_mem();
	strcpy(nt->sp, sp);
	nt->lineSeg = NULL;
	Mfa_addLineSeg(nt, beg, end, line, isAddBullet);
	nt->beg = beg;
	nt->end = end;
}

static P2C_CHATTIERS *Mfa_addDepTiers(P2C_CHATTIERS *depTiers, long beg, long end, char *sp, char *line, char isAddBullet) {
	P2C_CHATTIERS *nt, *tnt;

	if (depTiers == NULL) {
		if ((depTiers=NEW(P2C_CHATTIERS)) == NULL)
			out_of_mem();
		nt = depTiers;
		nt->nextTier = NULL;
	} else {
		tnt= depTiers;
		nt = depTiers;
		while (nt != NULL) {
			if (!strcmp(nt->sp, sp)) {
				if (end > nt->end)
					nt->end = end;
				if (beg < nt->beg)
					nt->beg = beg;
				Mfa_addLineSeg(nt, beg, end, line, isAddBullet);
				return(depTiers);
			}
			if (beg < nt->beg)
				break;
			tnt = nt;
			nt = nt->nextTier;
		}
		if (nt == NULL) {
			tnt->nextTier = NEW(P2C_CHATTIERS);
			if (tnt->nextTier == NULL)
				out_of_mem();
			nt = tnt->nextTier;
			nt->nextTier = NULL;
		} else if (nt == depTiers) {
			depTiers = NEW(P2C_CHATTIERS);
			if (depTiers == NULL)
				out_of_mem();
			depTiers->nextTier = nt;
			nt = depTiers;
		} else {
			nt = NEW(P2C_CHATTIERS);
			if (nt == NULL)
				out_of_mem();
			nt->nextTier = tnt->nextTier;
			tnt->nextTier = nt;
		}
	}

	Mfa_fillNT(nt, beg, end, sp, line, isAddBullet);
	return(depTiers);
}

static P2C_CHATTIERS *Mfa_insertNT(P2C_CHATTIERS *nt, P2C_CHATTIERS *tnt) {
	if (nt == RootTiers) {
		RootTiers = NEW(P2C_CHATTIERS);
		if (RootTiers == NULL)
			out_of_mem();
		RootTiers->nextTier = nt;
		nt = RootTiers;
	} else {
		nt = NEW(P2C_CHATTIERS);
		if (nt == NULL)
			out_of_mem();
		nt->nextTier = tnt->nextTier;
		tnt->nextTier = nt;
	}
	return(nt);
}

static char Mfa_isPostCodes(char *line) {
	char bullet;
	int  sq;
	long i;

	sq = 0;
	bullet = FALSE;
	i = strlen(line) - 1;
	for (; i >= 0L && (isSpace(line[i]) || isdigit(line[i]) || line[i] == '#' || line[i] == '_' || bullet || sq); i--) {
		if (line[i] == HIDEN_C)
			bullet = !bullet;
		else if (line[i] == ']')
			sq++;
		else if (line[i] == '[') {
			sq--;
			if (line[i+1] != '+')
				return(FALSE);
		}
	}
	if (i < 0L)
		return(TRUE);
	else
		return(FALSE);
}

static long findEndTime(P2C_CHATTIERS *nt, long beg, long end, char *sp) {
	while (nt != NULL && end > nt->beg) {
		if (!strcmp(sp, nt->sp))
			return(nt->beg);
		nt = nt->nextTier;
	}
	return(end);
}

static int partiwcmp(const char *st1, const char *st2) { // st1- full, st2- part
	for (; toupper((unsigned char)*st1) == toupper((unsigned char)*st2) && *st2 != EOS; st1++, st2++) ;
	return(!*st2);
}

static P2C_CHATTIERS *Mfa_addToTiers(SECFILE *labF, P2C_CHATTIERS *lastSpTier, long beg, long end, char *sp, char *refSp, char *line, char isAddBullet) {
	int  i;
	char isPostCodeFound, isFirstTry, *stp;
	long tTime;
	P2C_CHATTIERS *nt, *tnt;

	if (RootTiers == NULL) {
		if ((RootTiers=NEW(P2C_CHATTIERS)) == NULL)
			out_of_mem();
		nt = RootTiers;
		nt->nextTier = NULL;
		tnt= RootTiers;
		if (partiwcmp(spareTier2, line)) {
			strcpy(spareTier2, spareTier2+strlen(line));
			for (i=0; spareTier2[i] != EOS && isSpace(spareTier2[i]); i++) ;
			if (i > 0)
				strcpy(spareTier2, spareTier2+i);
		}
	} else {
		isPostCodeFound = Mfa_isPostCodes(line);
repeat_add_tier:
		if (lastSpTier != RootTiers)
			isFirstTry = TRUE;
		else
			isFirstTry = FALSE;
		tnt= lastSpTier;
		nt = lastSpTier;
		while (nt != NULL) {
			if (sp[0] == '%') {
				if (beg >= nt->beg && beg < nt->end && uS.partcmp(refSp, nt->sp, FALSE, TRUE)) {
					nt->depTiers = Mfa_addDepTiers(nt->depTiers, beg, end, sp, line,isAddBullet);
					return(tnt);
				} else if (end-beg < 3 && beg >= nt->beg && beg <= nt->end && uS.partcmp(refSp, nt->sp, FALSE, TRUE)) {
					nt->depTiers = Mfa_addDepTiers(nt->depTiers, beg, end, sp, line, isAddBullet);
					return(tnt);
				} else if (beg < nt->beg) {
					tTime = findEndTime(nt, beg, end, refSp);
					nt = Mfa_insertNT(nt, tnt);
					Mfa_fillNT(nt, beg, tTime, refSp, "0.", isAddBullet);
					nt->depTiers = Mfa_addDepTiers(nt->depTiers, beg, end, sp, line, isAddBullet);
					return(tnt);
				}
			} else if (sp[0] == '*') {
				if (uS.IsUtteranceDel(spareTier2, 0)) {
					if (!fgets_cr(spareTier2, UTTLINELEN, labF->fp)) {
						fclose(labF->fp);
						spareTier2[0] = EOS;
						fprintf(stderr,"\n*** File \"%s\": line %ld.\n", labF->fname, labF->lineno);
						fprintf(stderr, "The .lab file ended prematurely\n");
						return(NULL);
					} else {
						uS.remblanks(spareTier2);
						if (partiwcmp(spareTier2, line)) {
							strcpy(spareTier2, spareTier2+strlen(line));
							for (i=0; spareTier2[i] != EOS && isSpace(spareTier2[i]); i++) ;
							if (i > 0)
								strcpy(spareTier2, spareTier2+i);
						} else {
							fprintf(stderr,"\n*** File \"%s\": line %ld.\n", labF->fname, labF->lineno);
							fprintf(stderr, "Word from .lab file does not match next word from .TextGrid file\n");
							stp = strchr(spareTier2, ' ');
							if (stp != NULL)
								*stp = EOS;
							fprintf(stderr, ".lab file word: %s\n", spareTier2);
							fprintf(stderr, ".TextGrid file word: %s\n", line);
							return(NULL);
						}
					}
					labF->lineno = labF->lineno + 1;
					nt = NULL;
					break;
				}
				if (partiwcmp(spareTier2, line)) {
					strcpy(spareTier2, spareTier2+strlen(line));
					for (i=0; spareTier2[i] != EOS && isSpace(spareTier2[i]); i++) ;
					if (i > 0)
						strcpy(spareTier2, spareTier2+i);
					nt->end = end;
					Mfa_addLineSeg(nt, beg, end, line, isAddBullet);
					return(tnt);
				} else {
					fprintf(stderr,"\n*** File \"%s\": line %ld.\n", labF->fname, labF->lineno);
					fprintf(stderr, "Word from .lab file does not match next word from .TextGrid file\n");
					stp = strchr(spareTier2, ' ');
					if (stp != NULL)
						*stp = EOS;
					fprintf(stderr, ".lab file word: %s\n", spareTier2);
					fprintf(stderr, ".TextGrid file word: %s\n", line);
					return(NULL);
				}
			}
			tnt = nt;
			nt = nt->nextTier;
		}
		if (sp[0] != '*' && isFirstTry && (nt == tnt || beg < tnt->beg)) {
			lastSpTier = RootTiers;
			goto repeat_add_tier;
		}
		if (nt == NULL) {
			tnt->nextTier = NEW(P2C_CHATTIERS);
			if (tnt->nextTier == NULL)
				out_of_mem();
			nt = tnt->nextTier;
			nt->nextTier = NULL;
			if (sp[0] == '%') {
				Mfa_fillNT(nt, beg, end, refSp, "0.", isAddBullet);
				nt->depTiers = Mfa_addDepTiers(nt->depTiers, beg, end, sp, line, isAddBullet);
				return(tnt);
			}
		} else 
			nt = Mfa_insertNT(nt, tnt);
		if (sp[0] == '*')
			tnt = nt;
	}

	Mfa_fillNT(nt, beg, end, sp, line, isAddBullet);
	return(tnt);
}

#define timeMatch(sp,dep) (sp->beg >= dep->beg-1 && sp->beg <= dep->beg+1 && sp->end >= dep->end-1 && sp->end <= dep->end+1)

static void PropagateCode(P2C_CHATTIERS *cur_nt, char *tag, P2C_LINESEG *lineSeg, P2C_CHATTIERS *nt) {
	char ftime = TRUE, *s;
	long end, tempEnd;

	s = lineSeg->text;
	end = lineSeg->end;
	while (nt != NULL && end > nt->beg) {
		if (!strcmp(cur_nt->sp, nt->sp)) {
			if (ftime) {
				ftime = FALSE;
				lineSeg->end = cur_nt->end;
				strcpy(templineC4, "$b ");
				strcat(templineC4, s);
				lineSeg->text = (char *)malloc(strlen(templineC4)+1);
				if (lineSeg->text == NULL)
					out_of_mem();
				strcpy(lineSeg->text, templineC4);
			}

			if (end > nt->end) {
				tempEnd = nt->end;
				strcpy(templineC4, "$c ");
				strcat(templineC4, s);
			} else {
				tempEnd = end;
				strcpy(templineC4, "$e ");
				strcat(templineC4, s);
			}
			nt->depTiers = Mfa_addDepTiers(nt->depTiers, nt->beg, tempEnd, tag, templineC4, FALSE);
		}
		nt = nt->nextTier;
	}

	if (!ftime && s != NULL)
		free(s);
}

static void joinConsecutive(void) {
	char doJoin;
	P2C_CHATTIERS *nt, *prev_nt;
	P2C_LINESEG *lineSeg;
	P2C_CHATTIERS *depTier;

	nt = RootTiers;
	prev_nt = nt;
	while (nt != NULL) {
		if (prev_nt != nt) {
			if (!strcmp(prev_nt->sp, nt->sp)) {
				doJoin = FALSE;
				for (depTier=prev_nt->depTiers; depTier != NULL; depTier=depTier->nextTier) {
					if (depTier->end > nt->beg) {
						doJoin = TRUE;
						break;
					}
				}
				if (doJoin) {
					prev_nt->end = nt->end;
					if (prev_nt->depTiers == NULL)
						prev_nt->depTiers = nt->depTiers;
					else {
						for (depTier=prev_nt->depTiers; depTier->nextTier != NULL; depTier=depTier->nextTier) ;
						depTier->nextTier = nt->depTiers;
					}
					if (prev_nt->lineSeg == NULL)
						prev_nt->lineSeg = nt->lineSeg;
					else {
						for (lineSeg=prev_nt->lineSeg; lineSeg->nextSeg != NULL; lineSeg=lineSeg->nextSeg) {
							if (!strncmp(lineSeg->text, "0.", 2) && lineSeg->nextSeg != NULL) {
								lineSeg->text[0] = '(';
								lineSeg->text[1] = '.';
								lineSeg->text[2] = ')';
								lineSeg->text[3] = ' ';
							}
						}
						lineSeg->nextSeg = nt->lineSeg;
						for (; lineSeg != NULL; lineSeg=lineSeg->nextSeg) {
							if (!strncmp(lineSeg->text, "0.", 2)) {
								if (lineSeg == prev_nt->lineSeg && prev_nt->beg == nt->beg && prev_nt->end == nt->end) {
									lineSeg->text[0] = EOS;
								} else {
									lineSeg->text[0] = '(';
									lineSeg->text[1] = '.';
									lineSeg->text[2] = ')';
									lineSeg->text[3] = ' ';
								}
							}
						}
					}
					prev_nt->nextTier = nt->nextTier;
					if (nt->sp != NULL)
						free(nt->sp);
					free(nt);
					nt = prev_nt;
				}
			} else {
				for (depTier=prev_nt->depTiers; depTier != NULL; depTier=depTier->nextTier) {
					if (depTier->end > nt->beg) {
						for (lineSeg=depTier->lineSeg; lineSeg != NULL; lineSeg=lineSeg->nextSeg) {
							if (lineSeg->end > nt->beg)
								PropagateCode(prev_nt, depTier->sp, lineSeg, nt);
						}
					}
				}
			}
		}
		prev_nt = nt;
		nt = nt->nextTier;
	}
}

static void Mfa_finalTimeSort(void) {
	P2C_CHATTIERS *nt, *prev_nt, *prev_prev_nt;

	prev_nt = RootTiers;
	if (prev_nt != NULL) {
		nt = RootTiers->nextTier;
		if (nt != NULL && nt->sp[0] == '*' && prev_nt->sp[0] == '%') {
			if (nt->beg <= prev_nt->beg && nt->end >= prev_nt->beg) {
				prev_nt->nextTier = NULL;
				nt->depTiers = prev_nt;
				RootTiers = nt;
			}
		}
	}
	nt = RootTiers;
	prev_nt = nt;
	prev_prev_nt = nt;
	while (nt != NULL) {
		if (prev_nt != nt) {
			if (nt->beg == prev_nt->beg && nt->end < prev_nt->end) {
				prev_nt->nextTier = nt->nextTier;
				nt->nextTier = prev_nt;
				if (prev_prev_nt == RootTiers) {
					RootTiers = nt;
					prev_prev_nt = RootTiers;
				} else
					prev_prev_nt->nextTier = nt;
				prev_nt = prev_prev_nt;
				nt = prev_nt->nextTier;
			}
		}
		prev_prev_nt = prev_nt;
		prev_nt = nt;
		nt = nt->nextTier;
	}
	joinConsecutive();
}

static void Mfa_createLineFromSegs(char *line, P2C_CHATTIERS *nt, char whichLevel) {
	long i;
	P2C_LINESEG *seg;

	if (isMultiBullets) {
		nt->isWrap = TRUE;
	} else {
		nt->isWrap = FALSE;
	}
	seg = nt->lineSeg;
	line[0] = EOS;
	for (; seg != NULL; seg=seg->nextSeg) {
		strcat(line, seg->text);

		if (seg->text[0] != EOS) {
			if (whichLevel != 0)
				strcat(line, " ");
			else if (isMultiBullets)
				strcat(line, " ");
			else
				strcat(line, "\n\t");
		}
		if (strlen(line) > UTTLINELEN-50) {
			fprintf(stderr, "Out of memory!!! Tier is too long.\n");
			fprintf(stderr, "Line:\n");
			for (i=0L; line[i] != EOS; i++) {
				putc(line[i], stderr);
			}
			putc('\n', stderr);
			freeMfa2ChatMem();
			cutt_exit(0);
		}
	}

	i = ::strlen(line) - 1;
	while (i >= 0 && (isSpace(line[i]) || line[i] == '\n' || line[i] == ','))
		i--;
	line[i+1] = EOS;
}

static void Mfa_printOutTiers(P2C_CHATTIERS *nt, char whichLevel) {
	while (nt != NULL) {
		Mfa_createLineFromSegs(templineC3, nt, whichLevel);
		printout(nt->sp, templineC3, NULL, NULL, nt->isWrap);
		if (nt->depTiers != NULL)
			Mfa_printOutTiers(nt->depTiers, 1);
		nt = nt->nextTier;
	}
}

static void Mfa_makeText(char *line) {
	long  e, i, j;
	AttTYPE att, oldAtt;
	unsigned int hex;

	i = 0L;
	j = 0L;
	oldAtt = 0;
	while (line[i] != EOS) {
		if (!strncmp(line+i, "&quot;", 6)) {
			templineC[j++] = '"';
			i += 6;
		} else if (line[i] == '{' && line[i+1] == '0' && (line[i+2] == 'x' || line[i+2] == 't')) {
			for (e=i; line[e] != EOS && line[e] != '}'; e++) ;
			if (line[e] == '}') {
				if (line[i+2] == 't') {
					sscanf(line+i+3, "%x", &hex);
					att = hex;
					j = DealWithAtts_cutt(templineC, j, att, oldAtt);
					oldAtt = att;
				} else {
					sscanf(line+i+3, "%x", &hex);
					templineC[j++] = hex;
				}
				i = e + 1;
			} else
				templineC[j++] = line[i++];
		} else
			templineC[j++] = line[i++];
	}
	templineC[j] = EOS;
	strcpy(line, templineC);
}

static void extractSpeakerName(char *text, char *sp) {
	int i;
	char *p1, *p2;
	ATTRIBS *p;

	for (i=0; isSpace(text[i]) || text[i] == '"' || text[i] == '\n'; i++) ;
	if (i > 0)
		strcpy(text, text+i);
	for (i=strlen(text)-1; i >= 0 && (isSpace(text[i]) || text[i] == '"' || text[i] == '\n'); i--) ;
	i++;
	text[i] = EOS;
	uS.remFrontAndBackBlanks(text);
	for (p=attsRoot; p != NULL; p=p->nextTag) {
		if (uS.mStricmp(p->tag, text) == 0)
			break;
	}	
	sp[0] = EOS;

	if (p == NULL) {
		p1 = strchr(text, '[');
		if (p1 != NULL) {
			if (uS.partwcmp(p1, "[main]")) {
				*p1 = EOS;
				uS.remblanks(text);
				if (text[0] != '*' && text[0] != '%' && text[0] != '@')
					strcpy(sp, "*");
				else
					sp[0] = EOS;
				strcat(sp, text);
			} else if (p1[0] == '[' && p1[1] == '%') {
				p2 = strrchr(text, ']');
				if (p2 != NULL)
					*p2 = EOS;
				uS.remblanks(text);
				strcpy(sp, p1+1);
				*p1 = EOS;
				uS.remblanks(text);
				strcat(sp, "@");
				strcat(sp, text);
				if (text[0] == EOS)
					sp[0] = EOS;
			} else if (attsRoot != NULL) {
				fprintf(stderr, "\r ** Can't match praat tag \"%s\" to CHAT declaration in attributes file.\n", text);
			} else {
				p2 = strrchr(text, ']');
				if (p2 != NULL)
					*p2 = EOS;
				uS.remblanks(text);
				if (*(p1+1) != '*' && *(p1+1) != '%' && *(p1+1) != '@')
					strcpy(sp, "%");
				else
					sp[0] = EOS;
				strcat(sp, p1+1);
				*p1 = EOS;
				uS.remblanks(text);
				strcat(sp, "@");
				strcat(sp, text);
				if (text[0] == EOS)
					sp[0] = EOS;
			}
		} else {
			p1 = strchr(text, '(');
			if (p1 != NULL) {
				p2 = strrchr(text, ')');
				if (p2 != NULL)
					*p2 = EOS;
				*p1 = EOS;
				p1++;
				if (uS.partwcmp(text, "ortografi") || uS.partwcmp(text, "Ortografi") || uS.partwcmp(text, "ORTOGRAFI")) {
					if (p1[0] != '*' && p1[0] != '%' && p1[0] != '@')
						strcpy(sp, "*");
					else
						sp[0] = EOS;
					strcat(sp, p1);
				} else if (attsRoot != NULL) {
					fprintf(stderr, "\r ** Can't match praat tag \"%s\" to CHAT declaration in attributes file.\n", text);
				} else {
					uS.remblanks(text);
					if (text[0] != '*' && text[0] != '%' && text[0] != '@')
						strcpy(sp, "%");
					else
						sp[0] = EOS;
					strcat(sp, text);
					strcat(sp, "@");
					strcat(sp, p1);
					if (text[0] == EOS)
						sp[0] = EOS;
				}
			} else if (uS.mStricmp(text, "ortho") == 0) {
				strcpy(sp, "*SPK");
			} else if (uS.mStricmp(text, "phono") == 0) {
				strcpy(sp, "%pho@SPK");
			} else if (*text == '*') {
				strcpy(sp, text);
				uS.uppercasestr(sp, &dFnt, FALSE);
			} else if (*text == '%') {
				strcpy(sp, text);
				uS.lowercasestr(sp, &dFnt, FALSE);
			} else {
				fprintf(stderr, "\r ** Can't match praat tag \"%s\" to CHAT declaration in attributes file.\n", text);
			}
		}
	} else {
		strcpy(sp, p->chatName);
		if (p->chatName[0] != '*') {
			strcat(sp, "@");
			if (p->depOn[0] == '*')
				strcat(sp, p->depOn+1);
			else
				strcat(sp, p->depOn);
		}
	}
}

#ifdef _WIN32 
#include <mbstring.h>
static void AsciiToUnicodeToUTF8(char *src, char *line) {
	long UTF8Len;
	long total = strlen(src);
	long wchars=MultiByteToWideChar(lEncode,0,(const char*)src,total,NULL,0);
	
	MultiByteToWideChar(lEncode,0,(const char*)src,total,templineW,wchars);
	UnicodeToUTF8(templineW, wchars, (unsigned char *)line, (unsigned long *)&UTF8Len, UTTLINELEN);
	if (UTF8Len == 0 && wchars > 0) {
		putc('\n', stderr);
		fprintf(stderr,"\n*** File \"%s\": line %ld.\n", oldfname, lineno);
		fprintf(stderr, "Fatal error: Unable to convert the following line:\n");
		fprintf(stderr, "%s\n", src);
	}
}
#endif

#ifdef _MAC_CODE
static void AsciiToUnicodeToUTF8(char *src, char *line) {
	OSStatus err;
	long len;
	TECObjectRef ec;
	TextEncoding utf8Encoding;
	TextEncoding MacRomanEncoding;
	unsigned long ail, aol;
	
	MacRomanEncoding = CreateTextEncoding( (long)lEncode, lVariant, kTextEncodingDefaultFormat );
	utf8Encoding = CreateTextEncoding( kTextEncodingUnicodeDefault, kTextEncodingDefaultVariant, kUnicodeUTF8Format );
	if ((err=TECCreateConverter(&ec, MacRomanEncoding, utf8Encoding)) != noErr) {
		fprintf(stderr,"\n*** File \"%s\": line %ld.\n", oldfname, lineno);
		fprintf(stderr, "Fatal error1: Unable to create a converter.\n");
		fprintf(stderr, "%s\n", src);
		freeXML_Elements();
		freeMfa2ChatMem();
		cutt_exit(0);
	}
	
	len = strlen(src);
	if ((err=TECConvertText(ec, (ConstTextPtr)src, len, &ail, (TextPtr)line, UTTLINELEN, &aol)) != noErr) {
		putc('\n', fpout);
		fprintf(stderr,"\n*** File \"%s\": line %ld.\n", oldfname, lineno);
		fprintf(stderr, "Fatal error2: Unable to convert the following line:\n");
		fprintf(stderr, "%s\n",src);
		freeXML_Elements();
		freeMfa2ChatMem();
		cutt_exit(0);
	}
	err = TECDisposeConverter(ec);
	if (ail < len) {
		putc('\n', fpout);
		fprintf(stderr,"\n*** File \"%s\": line %ld.\n", oldfname, lineno);
		fprintf(stderr, "Fatal error3: Converted only %ld out of %ld chars:\n", ail, len);
		fprintf(stderr, "%s\n", src);
		freeXML_Elements();
		freeMfa2ChatMem();
		cutt_exit(0);
	}
	line[aol] = EOS;
}
#endif

static void extractTierText(char *text, char *line, char isUnicode) {
	int  i;

	for (i=0; isSpace(text[i]) || text[i] == '"' || text[i] == '\n'; i++) ;
	if (i > 0)
		strcpy(text, text+i);
	for (i=strlen(text)-1; i >= 0 && (isSpace(text[i]) || text[i] == '"' || text[i] == '\n'); i--) ;
	i++;
	text[i] = EOS;

#ifdef UNX
	strcpy(line, text);
#else
	if (isUnicode == UTF8_code || isUnicode == UTF16_code)
		strcpy(line, text);
	else
		AsciiToUnicodeToUTF8(text, line);
#endif
}

static char getNextLine(char *st, int size, FILE *fp, char isUnicode, char *isNLFound) {
	long  i;

	if (isUnicode == UTF16_code) {
#ifdef UNX
		return(fgets_cr(st, UTTLINELEN, fpin) != NULL);
#else
		i = 0;
		while (!feof(fpin)) {
  #ifdef _WIN32 
			if (lEncode == UPC) {
				templineC1[i] = getc(fpin);
				if (feof(fpin))
					break;
				templineC1[i+1] = getc(fpin);
			} else {
				templineC1[i+1] = getc(fpin);
				if (feof(fpin))
					break;
				templineC1[i] = getc(fpin);
			}
  #else
			if (lEncode == UPC) {
				templineC1[i+1] = getc(fpin);
				if (feof(fpin))
					break;
				templineC1[i] = getc(fpin);
			} else {
				templineC1[i] = getc(fpin);
				if (feof(fpin))
					break;
				templineC1[i+1] = getc(fpin);
			}
  #endif
			if ((templineC1[i] == '\r' && templineC1[i+1] == EOS) ||
				(templineC1[i] == '\n' && templineC1[i+1] == EOS) ||
				(templineC1[i] == EOS  && templineC1[i+1] == '\r') ||
				(templineC1[i] == EOS  && templineC1[i+1] == '\n')) {

				if (templineC1[i] == '\r' && templineC1[i+1] == EOS)
					templineC1[i] = '\n';
				if (templineC1[i] == EOS  && templineC1[i+1] == '\r')
					templineC1[i+1] = '\n';

				if (*isNLFound) {
					*isNLFound = FALSE;
					i -= 2;
				} else {
					*isNLFound = TRUE;
					i += 2;
					break;
				}
			} else
				*isNLFound = FALSE;
			i += 2;
			if (i > UTTLINELEN-10)
				break;
		}
		templineC1[i] = EOS;
		templineC1[i+1] = EOS;
		UnicodeToUTF8((unCH *)templineC1, i/2, (unsigned char *)st, NULL, UTTLINELEN);
		return(!feof(fpin));
#endif
	} else {
		return(fgets_cr(st, UTTLINELEN, fpin) != NULL);
	}
}

static char Mfa_getNextTier(char *whichMode, UTTER *utterance, long *beg, long *end, char isUnicode) {
	int i;
	float xmin, xmax;
	double xmind, xmaxd;
	char isNLFound = FALSE;

	xmin = 0.0;
	xmax = 0.0;
	utterance->line[0] = EOS;
	while (getNextLine(templineC, UTTLINELEN, fpin, isUnicode, &isNLFound)) {
		for (i=0; isSpace(templineC[i]); i++) ;
		if (i > 0)
			strcpy(templineC, templineC+i);
		if (uS.partwcmp(templineC, "item ["))
			*whichMode = SP_MODE;
		else if (uS.partwcmp(templineC, "intervals ["))
			*whichMode = TIER_MODE;
		else if (*whichMode == SP_MODE) {
			if (uS.partwcmp(templineC, "name = "))
				extractSpeakerName(templineC+7, utterance->speaker);
		} else if (*whichMode == TIER_MODE) {
			if (uS.partwcmp(templineC, "xmin = "))
				xmin = atof(templineC+7);
			else if (uS.partwcmp(templineC, "xmax = "))
				xmax = atof(templineC+7);
			else if (uS.partwcmp(templineC, "text = ")) {
				xmind = (double)xmin * 1000.0000;
				*beg = (long)xmind;
				xmaxd = (double)xmax * 1000.0000;
				*end = (long)xmaxd;
				extractTierText(templineC+7, utterance->line, isUnicode);
				if (xmax != 0 && utterance->speaker[0] != EOS && utterance->line[0] != EOS)
					return(TRUE);
				xmin = 0.0;
				xmax = 0.0;
				utterance->line[0] = EOS;
			}
		}
	}
	return(FALSE);
}

static char UTFTestPass(void) {
	int  i;

#if defined(UNX)
	if (stin)
		return(TRUE);
#endif
	while (fgets_cr(templineC, UTTLINELEN, fpin)) {
		for (i=0; isSpace(templineC[i]); i++) ;
		if (uS.partwcmp(templineC+i, "name = \"[MAIN-CHAT-HEADERS]\"")) {
			rewind(fpin);
			return(TRUE);
		}
	}
	rewind(fpin);
	return(FALSE);
}

static P2C_TIERS *freeRootTiers(P2C_TIERS *p) {
	P2C_TIERS *t;

	while (p != NULL) {
		if (p->nextMfaTier != NULL)
			p->nextMfaTier = freeRootTiers(p->nextMfaTier);
		t = p;
		p = p->sameSP;
		if (t->sp != NULL)
			free(t->sp);
		if (t->line != NULL)
			free(t->line);
		free(t);
	}
	return(NULL);
}

static P2C_TIERS *add2SameSp(P2C_TIERS *sameSP, UTTER *utterance, long beg, long end) {
	P2C_TIERS *p;

	if (sameSP == NULL) {
		p = NEW(P2C_TIERS);
		if (p == NULL)
			out_of_mem();
		sameSP = p;
	} else {
		for (p=sameSP; p->sameSP != NULL; p=p->sameSP) ;
		p->sameSP = NEW(P2C_TIERS);
		p = p->sameSP;
		if (p == NULL)
			out_of_mem();
	}
	p->sp = NULL;
	p->line = (char *)malloc(strlen(utterance->line)+1);
	if (p->line == NULL)
		out_of_mem();
	strcpy(p->line, utterance->line);
	p->beg = beg;
	p->end = end;
	p->sameSP = NULL;
	p->nextMfaTier = NULL;
	return(sameSP);
}

static P2C_TIERS *add2Tiers(P2C_TIERS *rootMfaTiers, UTTER *utterance, long beg, long end) {
	P2C_TIERS *p, *t;

	p = NEW(P2C_TIERS);
	if (p == NULL)
		out_of_mem();
	p->nextMfaTier = NULL;
	if (rootMfaTiers == NULL) {
		rootMfaTiers = p;
	} else {
		for (t=rootMfaTiers; t->nextMfaTier != NULL; t=t->nextMfaTier) {
			if (uS.mStricmp(t->sp, utterance->speaker) == 0) {
				t->sameSP = add2SameSp(t->sameSP, utterance, beg, end);
				return(rootMfaTiers);
			}
		}
		if (uS.mStricmp(t->sp, utterance->speaker) == 0) {
			t->sameSP = add2SameSp(t->sameSP, utterance, beg, end);
			return(rootMfaTiers);
		}
		t->nextMfaTier = p;
	}
	p->sp = (char *)malloc(strlen(utterance->speaker)+1);
	if (p->sp == NULL)
		out_of_mem();
	strcpy(p->sp, utterance->speaker);
	p->line = (char *)malloc(strlen(utterance->line)+1);
	if (p->line == NULL)
		out_of_mem();
	strcpy(p->line, utterance->line);
	p->beg = beg;
	p->end = end;
	p->sameSP = NULL;
	return(rootMfaTiers);
}

static void mergeWithChat(void) {
	int  i, j, wi, len, offset;
	char word[BUFSIZ], *stp;
	FNType *oldExt;
	SECFILE inF;
	P2C_CHATTIERS *nt;
	P2C_LINESEG *seg;

	chatmode = 1;
	strcpy(inF.fname, oldfname);
	oldExt = strrchr(inF.fname, '.');
	if (oldExt != NULL)
		*oldExt = EOS;
	strcat(inF.fname, ".cha");
	inF.fp = fopen(inF.fname, "r");
	if (inF.fp == NULL) {
		freeMfa2ChatMem();
		fprintf(stderr, "Can't open original .cha file: %s\n", inF.fname);
		cutt_exit(0);
	}
	fclose(fpin);
	nt = RootTiers;
	fpin = inF.fp;
	lineno = 0;
	currentatt = 0;
	currentchar = (char)getc_cr(fpin, &currentatt);
	while (getwholeutter()) {
		if (utterance->speaker[0] == '*') {
			if (nt != NULL)
				seg = nt->lineSeg;
			else
				seg = NULL;
			offset = 0;
			i = 0;
			while ((i=getword(utterance->speaker, uttline, word, &wi, i))) {
				if (nt == NULL || seg == NULL) {
					fprintf(stderr,"\n*** File \"%s\": line %ld.\n", inF.fname, lineno);
					fprintf(stderr, "The .TextGrid file ended prematurely\n");
					cutt_exit(0);
				}
				strcpy(spareTier2, seg->text);
				uS.remblanks(spareTier2);
				if (partiwcmp(spareTier2, word)) {
					strcpy(spareTier2, spareTier2+strlen(word));
					for (j=0; spareTier2[j] != EOS && isSpace(spareTier2[j]); j++) ;
					if (j > 0)
						strcpy(spareTier2, spareTier2+j);
				} else {
					fprintf(stderr,"\n*** File \"%s\": line %ld.\n", inF.fname, lineno);
					fprintf(stderr, "Word from .cha file does not match next word from .TextGrid file\n");
					stp = strchr(spareTier2, ' ');
					if (stp != NULL)
						*stp = EOS;
					fprintf(stderr, ".cha file word: %s\n", word);
					fprintf(stderr, ".TextGrid file word: %s\n", spareTier2);
					cutt_exit(0);
				}
				wi = wi + offset;
				while (!uS.isskip(utterance->line, wi, &dFnt, MBF) && utterance->line[wi] != EOS)
					wi++;
				len = strlen(spareTier2);
				att_shiftright(utterance->line+wi, utterance->attLine+wi, len+1);
				offset += len + 1;
				utterance->line[wi] = ' ';
				utterance->attLine[wi] = 0;
				wi++;
				for (j=0; spareTier2[j] && j < len; j++) {
					utterance->line[wi] = spareTier2[j];
					utterance->attLine[wi] = 0;
					wi++;
				}
				seg = seg->nextSeg;
			}
			printout(utterance->speaker,utterance->line,utterance->attSp,utterance->attLine,FALSE);
			if (nt != NULL) {
				if (nt->depTiers != NULL)
					Mfa_printOutTiers(nt->depTiers, 1);
				nt = nt->nextTier;
			}
		} else {
			printout(utterance->speaker,utterance->line,utterance->attSp,utterance->attLine,FALSE);
			if (uS.partcmp(utterance->speaker, "@Participants", FALSE, FALSE)) {
				fprintf(fpout, "@Options:\tmulti\n");
			}
		}
	}
//	Mfa_printOutTiers(RootTiers, 0);
	chatmode = CHAT_MODE;
}

void call() {		/* this function is self-explanatory */
	char refSp[SPEAKERLEN], lastSp[SPEAKERLEN], *p, whichMode, isUnicode;
	FNType *oldExt;
	long len;
	long beg, end;
	long lineno, tlineno;
	SECFILE inF;
	P2C_TIERS *rootMfaTiers, *MfaTier, *SPTier;
	P2C_CHATTIERS *lastSpTier;

	if (attsRoot == NULL) {
		rd_MfaAtts_f("attribs.cut", TRUE);
	}
	isUnicode = ANSI_code;
	if (!feof(fpin)) {
		int  c;

		c = getc(fpin);
		if (c == (int)0xFF || c == (int)0xFE) {
			if (c == (int)0xFF)
				lEncode = UPC;
			else
				lEncode = UMAC;
			isUnicode = UTF16_code;
		}
#if defined(UNX)
		if (!stin)
#endif
			rewind(fpin);
	}
	if (isUnicode == UTF16_code) {
		fclose(fpin);
		if ((fpin=fopen(oldfname, "rb")) == NULL) {
			fprintf(stderr,"Can't open file %s.\n",oldfname);
			cutt_exit(0);
		}
		getc(fpin);
		if (!feof(fpin))
			getc(fpin);

#ifdef _MAC_CODE
		if (byteOrder == CFByteOrderLittleEndian) {
			if (lEncode == UPC)
				lEncode = UMAC;
			else 
				lEncode = UPC;
		}
#endif
	} else if (lEncode == 0xFFFF)
		isUnicode = UTF8_code;
	else if (UTFTestPass())
		isUnicode = UTF8_code;
	else if (lEncode == 0) {
		freeMfa2ChatMem();
		fprintf(stderr, "Please specify text encoding with +o option.\n");
		cutt_exit(0);
	}
	lineno = 0L;
	tlineno = 0L;
	whichMode = 0;
	utterance->speaker[0] = EOS;
	SPTier = NULL;
	rootMfaTiers = NULL;
	while (Mfa_getNextTier(&whichMode, utterance, &beg, &end, isUnicode)) {
		if (lineno > tlineno) {
			tlineno = lineno + 500;
			fprintf(stderr,"\r%ld ",lineno);
		}
		lineno++;
		if (utterance->speaker[0] == '*')
			SPTier = add2Tiers(SPTier, utterance, beg, end);
		else
			rootMfaTiers = add2Tiers(rootMfaTiers, utterance, beg, end);
	}
	if (SPTier != NULL) {
		for (MfaTier=SPTier; MfaTier->nextMfaTier != NULL; MfaTier=MfaTier->nextMfaTier) ;
		MfaTier->nextMfaTier = rootMfaTiers;
		rootMfaTiers = SPTier;
	}
	strcpy(inF.fname, oldfname);
	oldExt = strrchr(inF.fname, '.');
	if (oldExt != NULL)
		*oldExt = EOS;
	strcat(inF.fname, ".lab");
	inF.fp = fopen(inF.fname, "r");
	if (inF.fp == NULL) {
		freeMfa2ChatMem();
		fprintf(stderr, "Can't open intermediate .lab file: %s\n", inF.fname);
		cutt_exit(0);
	}
	fgets_cr_lc = '\0';
	if (!fgets_cr(spareTier2, UTTLINELEN, inF.fp)) {
		fclose(inF.fp);
		fprintf(stderr, "The .lab file \"%s\" is empty\n", inF.fname);
		cutt_exit(0);
	}
	uS.remblanks(spareTier2);
	inF.lineno = 1L;
  	strcpy(mediaFName, "dummy.mov");
	refSp[0] = EOS;
	lastSp[0] = EOS;
	lastSpTier = RootTiers;
	MfaTier = rootMfaTiers;
	SPTier = MfaTier;
	while (MfaTier != NULL) {
		while (SPTier == NULL) {
			MfaTier = MfaTier->nextMfaTier;
			if (MfaTier == NULL)
				break;
			SPTier = MfaTier;
		}
		if (MfaTier == NULL)
			break;
		if (SPTier->sp != NULL)
			strcpy(utterance->speaker, SPTier->sp);
		strcpy(utterance->line, SPTier->line);
		beg = SPTier->beg;
		end = SPTier->end;
		SPTier = SPTier->sameSP;
		if (strcmp(lastSp, utterance->speaker)) {
			lastSpTier = RootTiers;
		}
		strcpy(lastSp, utterance->speaker);
		uS.remblanks(utterance->speaker);
/*
 if (strcmp(utterance->speaker, "%gpx@BET") == 0)
	len = 0;
*/
		if (utterance->speaker[0] == '%') {
			p = strchr(utterance->speaker, '@');
			if (p != NULL) {
				strcpy(refSp, "*");
				strcat(refSp, p+1);
				len = strlen(refSp);
				if (refSp[len-1] != ':')
					strcat(refSp, ":");
				*p = EOS;
			}
		} else
			refSp[0] = EOS;
		len = strlen(utterance->speaker);
		if (utterance->speaker[len-1] != ':')
			strcat(utterance->speaker, ":");
		Mfa_makeText(utterance->line);
		lastSpTier = Mfa_addToTiers(&inF, lastSpTier, beg, end, utterance->speaker, refSp, utterance->line, TRUE);
		if (lastSpTier == NULL) {
			freeMfa2ChatMem();
			cutt_exit(0);
		}
	}
	if (inF.fp != NULL) {
		fclose(inF.fp);
		inF.fp = NULL;
	}
	rootMfaTiers = freeRootTiers(rootMfaTiers);
	fprintf(stderr, "\r	                      \r");
	Mfa_finalTimeSort();
	cutt_isMultiFound = isMultiBullets;

	mergeWithChat();
	
	RootTiers = freeTiers(RootTiers);
}
