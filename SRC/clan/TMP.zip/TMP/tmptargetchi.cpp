/**********************************************************************
 "Copyright 1990-2016 Brian MacWhinney. Use is subject to Gnu Public License
 as stated in the attached "gpl.txt" file."
 */

#define CHAT_MODE 3
#include "cu.h"
#include "check.h"

#if !defined(UNX)
#define _main temp_main
#define call temp_call
#define getflag temp_getflag
#define init temp_init
#define usage temp_usage
#endif

#define IS_WIN_MODE FALSE
#include "mul.h" 

extern struct tier *defheadtier;
extern char OverWriteFile;

static char ftime;
static char tReplaceFile;

void usage() {
	printf("Usage: targetchi [cS %s] filename(s)\n",mainflgs());
	mainusage(FALSE);
	puts("\nExample: targetchi +re +1 \"*.cha\"");
	puts("         targetchi +1 *.cha");
	cutt_exit(0);
}

void init(char f) {
	if (f) {
		stout = FALSE;
		onlydata = 1;
		OverWriteFile = TRUE;
		FilterTier = 0;
		LocalTierSelect = TRUE;
		if (defheadtier != NULL) {
			if (defheadtier->nexttier != NULL)
				free(defheadtier->nexttier);
			free(defheadtier);
			defheadtier = NULL;
		}
		ftime = TRUE;
	} else {
		if (ftime) {
			ftime = FALSE;
			tReplaceFile = replaceFile;
		}
	}
}

CLAN_MAIN_RETURN main(int argc, char *argv[]) {
	isWinMode = IS_WIN_MODE;
	chatmode = CHAT_MODE;
	CLAN_PROG_NUM = TEMP;
	OnlydataLimit = 0;
	UttlineEqUtterance = TRUE;
	bmain(argc,argv,NULL);
}
		
void getflag(char *f, char *f1, int *i) {
	f++;
	switch(*f++) {
		default:
			maingetflag(f-2,f1,i);
			break;
	}
}

static char checkspinfo(char res, char *sp, char *role, char *isTargetChiFound, char *spO, char *errCode) {

	if (strcmp(sp, "CHI") == 0 && strcmp(role, "Target_Child") == 0) {
		res = 2;
		*errCode = 0;
	} else if (strcmp(sp, "CHI") == 0) {
		if (res == 3 || res == 4)
			*errCode = 1;
		else
			res = 1;
	} else if (strcmp(role, "Target_Child") == 0) {
		if (res == 1)
			*errCode = 1;
		else if (res == 3)
			res = 4;
		else if (res != 4)
			res = 3;
		strcpy(spO, sp);
	}
	return(res);
}

static char getParticipants(char *line, char *spO, char *errCode) {
	int i;
	char sp[SPEAKERLEN];
	char *s, *e, t, wc, res, isTargetChiFound;
	long ln = 0L;
	short cnt = 0;

	for (; *line && (*line == ' ' || *line == '\t'); line++) ;
	s = line;
	sp[0] = EOS;
	isTargetChiFound = FALSE;
	res = 0;
	while (*s) {
		if (*line == ','  || *line == ' '  ||
			*line == '\t' || *line == '\n' || *line == EOS) {

			wc = ' ';
			e = line;
			for (; *line == ' ' || *line == '\t' || *line == '\n'; line++) {
				if (*line == '\n')
					ln += 1L;
			}
			if (*line != ',' && *line != EOS)
				line--;
			else
				wc = ',';
			if (*line) {
				t = *e;
				*e = EOS;
				if (cnt == 2 || wc == ',') {
					res = checkspinfo(res,sp,s,&isTargetChiFound, spO, errCode);
					if (res == 2)
						return(res);
				} else if (cnt == 0) {
					for (i=0; s[i] > 32 && s[i] < 127 && s[i] != EOS; i++) ;
					if (s[i] == EOS) {
						strcpy(sp, s);
//						res = checkspinfo(res,s,NULL,&isTargetChiFound, spO, errCode);
//						if (res == 2)
//							return(res);
					}
				}
				*e = t;
				if (wc == ',') {
					cnt = -1;
					sp[0] = EOS;
				}
				for (line++; *line==' ' || *line=='\t' || *line=='\n' || *line==','; line++) {
					if (*line == ',') {
						cnt = -1;
						sp[0] = EOS;
					} else if (*line == '\n')
						ln += 1L;
				}
			} else {
				for (line=e; *line; line++) {
					if (*line == '\n')
						ln -= 1L;
				}
				if (cnt != 0) {
					t = *e;
					*e = EOS;
					res = checkspinfo(res,sp,s,&isTargetChiFound, spO, errCode);
					*e = t;
					if (res == 2)
						return(res);
				}
				for (line=e; *line; line++) {
					if (*line == '\n')
						ln += 1L;
				}
			}
			if (cnt == 2) {
				cnt = 0;
				sp[0] = EOS;
			} else
				cnt++;
			s = line;
		} else
			line++;
	}
	if (res == 4)
		*errCode = 2;
	return(res);
}

static void CleanTierNames(char *st) {
	register int i;

	i = strlen(st) - 1;
	while (i >= 0 && (st[i] == ' ' || st[i] == '\t' || st[i] == '\n')) i--;
	if (i >= 0 && st[i] == ':') i--;
	if (*st == '*') {
		int j = i;
		while (i >= 0 && st[i] != '-') i--;
		if (i < 0) i = j;
		else i--;
	}
	st[i+1] = EOS;
}

void call() {
	int  i, len;
	char res, errCode, spO[SPEAKERLEN];

	replaceFile = tReplaceFile;
	currentatt = 0;
	currentchar = (char)getc_cr(fpin, &currentatt);
	spO[0] = EOS;
	len = 0;
	errCode = 0;
	while (getwholeutter()) {
		strcpy(templineC, utterance->speaker);
		CleanTierNames(templineC);
		if (uS.patmat(templineC,PARTICIPANTS)) {
			res = getParticipants(uttline, spO, &errCode);
			if (errCode > 0 || res < 3 || spO[0] == EOS) {
				if (errCode == 1) {
					fprintf(stderr, "\n*** File \"%s\"\n", oldfname);
					fprintf(stderr, "Found Target_Child, but CHI code is already user by another speaker\n\n");
					spO[0] = EOS;
					len = 0;
//					cutt_exit(1);
				} else if (errCode == 2) {
					fprintf(stderr, "\n*** File \"%s\"\n", oldfname);
					fprintf(stderr, "Found multiple Target_Child and can't choose which one should have CHI code\n\n");
					spO[0] = EOS;
					len = 0;
//					cutt_exit(1);
				}
				replaceFile = FALSE;
				if (fpout != NULL && !stout) {
					fclose(fpout);
					fpout = NULL;
				}
				if (unlink(newfname))
					fprintf(stderr, "Can't delete output file \"%s\".", newfname);
				break;
			} else {
				len = strlen(spO);
				for (i=0; utterance->line[i] != EOS; i++) {
					if (strncmp(utterance->line+i, spO, len) == 0) {
						strcpy(utterance->line+i, utterance->line+i+len);
						uS.shiftright(utterance->line+i, 3);
						utterance->line[i]   = 'C';
						utterance->line[i+1] = 'H';
						utterance->line[i+2] = 'I';
						break;
					}
				}
			}
		} else if (spO[0] != EOS) {
			if (uS.patmat(templineC,IDOF)) {
				for (i=0; utterance->line[i] != EOS; i++) {
					if (utterance->line[i-1] == '|' && strncmp(utterance->line+i, spO, len) == 0 && utterance->line[i+len] == '|') {
						strcpy(utterance->line+i, utterance->line+i+len);
						uS.shiftright(utterance->line+i, 3);
						utterance->line[i]   = 'C';
						utterance->line[i+1] = 'H';
						utterance->line[i+2] = 'I';
						break;
					}
				}
			} else if (utterance->speaker[0] == '@') {
				for (i=0; utterance->speaker[i] != EOS; i++) {
					if (strncmp(utterance->speaker+i, spO, len) == 0) {
						strcpy(utterance->speaker+i, utterance->speaker+i+len);
						uS.shiftright(utterance->speaker+i, 3);
						utterance->speaker[i]   = 'C';
						utterance->speaker[i+1] = 'H';
						utterance->speaker[i+2] = 'I';
						break;
					}
				}
			} else if (utterance->speaker[0] == '*') {
				for (i=0; utterance->speaker[i] != EOS; i++) {
					if (strncmp(utterance->speaker+i, spO, len) == 0) {
						strcpy(utterance->speaker+i, utterance->speaker+i+len);
						uS.shiftright(utterance->speaker+i, 3);
						utterance->speaker[i]   = 'C';
						utterance->speaker[i+1] = 'H';
						utterance->speaker[i+2] = 'I';
						break;
					}
				}
			}
		}
		printout(utterance->speaker,utterance->line,utterance->attSp,utterance->attLine,FALSE);
	}
}
